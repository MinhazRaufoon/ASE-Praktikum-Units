#ifndef CAN_H_
#define CAN_H_
#include "lldconf.h"

/***************************************************************************
*                                Task 3                                    *
*                          Masking Configuration                           *
***************************************************************************/
#define MASK_REGISTER 0x00U
#define ACCEPTANCE_REGISTER 0x00U



#endif /* CAN_H_ */
