#include "components.h"
#include "can_lld_cfg.h"
#include "me_init.h"
#include "can.h"




/********************************************************************
 *                           TASK 2                                 *
 ********************************************************************/
void CANMsgBufInit(void)
{

/********************************************************************
*               CAN message buffer configuration                   *
*                    _____  ___  ___   ___                         *
*                   |_   _|/ _ \|   \ / _ \                        *
*                     | | | (_) | |) | (_) |                       *
*                     |_|  \___/|___/ \___/                        *
*                                                                  *
********************************************************************/
/* MB Code */
//CAN_0.BUF[].CS.B.CODE = ;
/* Standard format */
//CAN_0.BUF[].MSG_CS.B.IDE = ;
/* SRR */
//	CAN_0.BUF[].MSG_CS.B.SRR = ;
/* Data Frame */
//CAN_0.BUF[].MSG_CS.B.RTR = ;
/* Data Length */
//CAN_0.BUF[].CS.B.LENGTH = ;
/* STD_ID */
//CAN_0.BUF[].MSG_ID.B.STD_ID = ;
}



